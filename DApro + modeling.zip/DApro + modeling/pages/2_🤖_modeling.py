import streamlit as st
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Model Evaluation", page_icon="🤖")
st.title("🤖 Model Selector & Evaluation")

# Check if processed_data exists
if 'processed_data' not in st.session_state:
    st.warning("Please preprocess the data first from the 'Preprocessing' page.")
    st.stop()

# Split features and labels
processed_data = st.session_state['processed_data']
x = processed_data.drop(columns=['survived'])
y = processed_data['survived']

# Streamlit UI
st.markdown("---")
st.title("🧠 Model Selector: Logistic Regression vs SVM")

# Model and evaluation selection
model_choice = st.selectbox("Choose a model:", ["Logistic Regression", "SVM"])
train_method = st.radio("Choose evaluation method:", ["Train-Test Split", "KFold Cross-Validation"])

# Initialize the selected model
if model_choice == "Logistic Regression":
    model = LogisticRegression()
elif model_choice == "SVM":
    model = SVC(kernel='rbf')

# Perform evaluation
if train_method == "Train-Test Split":
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

    model.fit(x_train, y_train)
    y_pred = model.predict(x_test)

    # Evaluation results
    acc = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)
    report = classification_report(y_test, y_pred, output_dict=True)

    st.subheader("📊 Evaluation Results - Train-Test Split")
    st.write(f"**Accuracy:** {acc:.4f}")
    st.write("**Classification Report:**")
    st.dataframe(pd.DataFrame(report).transpose())
    
    # Confusion matrix heatmap
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax)
    ax.set_title('Confusion Matrix')
    ax.set_xlabel('Predicted')
    ax.set_ylabel('Actual')
    st.pyplot(fig)

elif train_method == "KFold Cross-Validation":
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    cross_val_results = cross_val_score(model, x, y, cv=kf, scoring='accuracy')

    st.subheader("📊 Evaluation Results - KFold Cross-Validation")
    st.write(f"**Accuracy Scores:** {cross_val_results}")
    st.write(f"**Mean Accuracy:** {cross_val_results.mean():.4f}")
    st.write(f"**Standard Deviation:** {cross_val_results.std():.4f}")

