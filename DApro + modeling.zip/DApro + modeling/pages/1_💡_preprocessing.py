import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import io
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split

st.set_page_config(page_title="Data Preprocessing", page_icon="💡")

st.title("💡 Data Preprocessing")

# Load the dataset
st.subheader("📂 Load Titanic Dataset")
@st.cache_data
def load_data():
    return pd.read_csv('titanic_data.csv.xls')

df = load_data()
st.write("### Initial Dataset Preview", df.head())

# Show basic info
buffer = io.StringIO()
df.info(buf=buffer)
s = buffer.getvalue()
st.text(s)


# Show summary statistics
st.write("### Summary Statistics")
st.write(df.describe(include='all'))


# -----------------------------------------------
# 1. Handling Missing Values
# -----------------------------------------------

st.markdown("---")
st.subheader("🔍 Handling Missing Values")

# Heatmap of missing values
st.write("**Missing Values Heatmap**")
fig1, ax1 = plt.subplots(figsize=(10, 5))
sns.heatmap(df.isnull(), cbar=False, cmap='viridis', ax=ax1)
st.pyplot(fig1)

# Percentage of missing values
missing_percent = df.isnull().sum() / len(df) * 100
missing_percent = missing_percent[missing_percent > 0].sort_values(ascending=False)

st.write("**Percentage of Missing Values by Column**")
fig2, ax2 = plt.subplots()
missing_percent.plot(kind='bar', ax=ax2)
plt.ylabel("Percentage Missing")
st.pyplot(fig2)

# Handle missing values
st.write("**Applying Missing Value Treatment...**")

if 'who' in df.columns:
    df['age'] = df.groupby(['pclass', 'who'])['age'].transform(lambda x: x.fillna(x.median()))
else:
    df['age'] = df.groupby('pclass')['age'].transform(lambda x: x.fillna(x.median()))

if 'embarked' in df.columns:
    df['embarked'] = df['embarked'].fillna(df['embarked'].mode()[0])

df['fare'] = df.groupby('pclass')['fare'].transform(lambda x: x.fillna(x.median()))

for col in ['deck', 'embark_town']:
    if col in df.columns:
        df.drop(col, axis=1, inplace=True)

st.success("✅ Missing values handled.")

# -----------------------------------------------
# 2. Identifying and Removing Outliers
# -----------------------------------------------

st.markdown("---")
st.subheader("📦 Handling Outliers")

num_cols = ['age', 'fare', 'sibsp', 'parch']

# Before handling
st.write("**Before Handling Outliers**")
fig3, axes = plt.subplots(2, 2, figsize=(15, 10))
for i, col in enumerate(num_cols):
    sns.boxplot(x=df[col], ax=axes[i // 2, i % 2])
    axes[i // 2, i % 2].set_title(f'Boxplot of {col}')
st.pyplot(fig3)

# Handle outliers using IQR
for col in num_cols:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    df[col] = np.where(df[col] > upper, upper, df[col])

# After handling
st.write("**After Handling Outliers**")
fig4, axes = plt.subplots(2, 2, figsize=(15, 10))
for i, col in enumerate(num_cols):
    sns.boxplot(x=df[col], ax=axes[i // 2, i % 2])
    axes[i // 2, i % 2].set_title(f'{col} After Outlier Treatment')
st.pyplot(fig4)


# -----------------------------------------------
# 3. Checking and Removing Duplicates
# -----------------------------------------------

st.markdown("---")
st.subheader("📑 Removing Duplicates")

before = df.shape[0]
duplicates = df.duplicated().sum()
df = df.drop_duplicates()
after = df.shape[0]

st.write(f"**Duplicates Found:** {duplicates}")
st.write(f"**Rows before:** {before}, **Rows after:** {after}")

st.success("✅ Data is clean and ready for modeling!")

# Preview Cleaned Data
if st.checkbox("Show Cleaned Dataset", key="show_cleaned_data_1"):
    st.dataframe(df.head())


# -----------------------------------------------
# 4. Encode and Scale Features
# -----------------------------------------------

st.markdown("---")
st.subheader("🔠 Encoding and Scaling Features")

# Make a copy of the original DataFrame
encoded = df.copy()

# Display data types before encoding
st.write("#### Data Types Before Encoding:")
st.write(encoded.dtypes)

# Encode categorical features using LabelEncoder
le = LabelEncoder()
for col in encoded.select_dtypes(include=['object', 'category']).columns:
    encoded[col] = le.fit_transform(encoded[col])

# Display data types after encoding
st.write("#### Data Types After Encoding:")
st.write(encoded.dtypes)

# Visualize feature distributions before scaling
cols_count = len(encoded.columns)
# rows = ceil(cols_count / 3)
rows = int(cols_count / 3) + (cols_count % 3 > 0) 
sns.set_theme(style="whitegrid")

fig1, axes1 = plt.subplots(rows, 3, figsize=(15, rows * 3))
plt.suptitle('Distributions of Features Before Scaling', fontsize=20, y=1.02)

for i, col in enumerate(encoded.columns, 1):
    ax = axes1[(i - 1) // 3, (i - 1) % 3]
    sns.histplot(encoded[col], kde=True, ax=ax)
    ax.set_title(f'{col} Distribution')

plt.tight_layout()
plt.subplots_adjust(top=0.92)
st.pyplot(fig1)

# Split features and target
X = encoded.drop(columns=['survived'])
y = encoded['survived']

# Apply standard scaling
scaler = StandardScaler()
x_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

# Visualize feature distributions after scaling
fig2, axes2 = plt.subplots(rows, 3, figsize=(15, rows * 3))
plt.suptitle('Distributions of Features After Scaling', fontsize=20, y=1.02)

for i, col in enumerate(x_scaled.columns, 1):
    ax = axes2[(i - 1) // 3, (i - 1) % 3]
    sns.histplot(x_scaled[col], kde=True, ax=ax)
    ax.set_title(f'{col} Distribution')

plt.tight_layout()
plt.subplots_adjust(top=0.92)
st.pyplot(fig2)

# Combine scaled features with target into processed_data
processed_data = x_scaled.copy()
processed_data['survived'] = y.values

# Store in session_state
st.session_state['processed_data'] = processed_data

# Option to preview the processed dataset
if st.checkbox("Show Processed Dataset", key="show_processed_data"):
    st.write("### Preview of Processed Data")
    st.dataframe(processed_data.head())
    st.write(f"Dataset shape: {processed_data.shape}")




# # -----------------------------------------------
# # 4. Encode Categorical Data
# # -----------------------------------------------

# st.markdown("---")
# st.subheader("🔠 Encoding Categorical Features")

# # Convert categorical data to numeric using LabelEncoder
# encoded = df.copy()
# le = LabelEncoder()

# for col in encoded.select_dtypes(include=['object', 'category']).columns:
#     encoded[col] = le.fit_transform(encoded[col])

# st.write("### Encoded Data Preview", encoded.head())

# # Visualize distributions before scaling
# cols_count = len(encoded.columns)
# rows = int(cols_count / 3) + (cols_count % 3 > 0) 

# sns.set_theme(style="whitegrid")

# fig, axes = plt.subplots(rows, 3, figsize=(15, rows * 3))  # Create subplots
# plt.suptitle('Distributions of Features Before Scaling', fontsize=20, y=1.02)

# for i, col in enumerate(encoded, 1):
#     ax = axes[(i - 1) // 3, (i - 1) % 3]
#     sns.histplot(encoded[col], kde=True, ax=ax)  
#     ax.set_title(f'{col} Distribution')

# plt.tight_layout()
# plt.subplots_adjust(top=0.92)

# st.pyplot(fig)


# # Scaling features
# scaler = StandardScaler()
# scaled = pd.DataFrame(scaler.fit_transform(encoded), columns=df.columns)

# # Visualize distributions after scaling
# fig, axes = plt.subplots(rows, 3, figsize=(15, rows * 3))
# plt.suptitle('Distributions of Features After Scaling', fontsize=20, y=1.02)

# for i, col in enumerate(scaled, 1):
#     ax = axes[(i - 1) // 3, (i - 1) % 3]  
#     sns.histplot(scaled[col], kde=True, ax=ax)   
#     ax.set_title(f'{col} Distribution')

# plt.tight_layout()
# plt.subplots_adjust(top=0.92)
# st.pyplot(fig)

# # Preview Cleaned Data
# if st.checkbox("Show Cleaned Dataset", key="show_cleaned_data_2"):
#     st.dataframe(df.head())
