import streamlit as st

# Page configuration
st.set_page_config(
    page_title="Welcome | Data Analysis App",
    page_icon="📊",
    layout="centered"
)

# Title
st.title("Welcome to the Data Analysis App")
st.markdown("---")

# Subtitle
st.subheader("📊 Preprocessing, data visualization, Apply ML algorithm and evaluate its performance — All in One Place")

st.image("https://static.vecteezy.com/system/resources/previews/000/472/916/original/vector-big-data-analysis-concept-flat-poster.jpg", width=700)

# st.sidebar.title('Pages')
# Intro text
st.markdown("""
This app allows you to show:

- visualization of data cleaning and preprocessing 
- Train data using train-test-split and k-fold to compare between them
- Apply suitable ML algorithm 
- ML model evaluation
            
       ⚓ On Titanic data 🛳️

No coding needed. Just navigate through the pages.
""")

# with st.expander("ℹ️ How this app works"):
#     st.markdown(""" 
#     """)

# Footer
st.markdown("---")
st.markdown("Made by Noor Shukri | Alyaa Waleed | Malak Abd El-satar | Mena Khwaga | Mohamed El-feky | Ahmed shamh | Mohamed ibrahim  | © 2025")


